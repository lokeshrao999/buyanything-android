# buyanything — Android-ready food delivery prototype

A responsive, installable Progressive Web App (PWA) based on the uploaded Adalo blueprint's blue branding and food browsing concept.

## Included features
- Blue branded home screen and promotional offer
- Search, food categories, and filters (vegetarian, under 20 minutes, popular)
- Food cards with price, rating, preparation estimate, and vegetarian labels
- Persistent cart and quantity controls
- Demo checkout with delivery address form (no payment)
- ₹80 demo savings on item totals of ₹299 or more; delivery fee shown separately
- Favorites, order history, and step-by-step *simulated* order tracker
- Minimal-packaging toggle and dark mode
- Local browser storage and offline caching after first load
- Responsive mobile layout and Android home-screen install support

## Important limitations
This is a functional front-end prototype. It does **not** connect to real restaurants, couriers, maps, payments, SMS, or a cloud database. Orders, favorites, and cart data are saved on the current device/browser only. Tracking steps are simulated. The included prices and offers are sample demo data.

## Run it on Android
### Quick local preview
Open `index.html` in a browser to preview basic UI. Some browser features (offline caching and install prompt) require serving it over HTTPS or localhost.

### Install as an Android home-screen app
1. Host the folder on an HTTPS static host (for example GitHub Pages, Netlify, or another static host).
2. Open the hosted URL in Chrome on Android.
3. Open Chrome's menu and choose **Install app** or **Add to Home screen**.

### For a true APK
This ZIP is not a compiled APK. To publish a Play Store APK/AAB, add a native Android wrapper or build a native Android app, configure signing, and test it. Real orders require a backend, database, authentication, and payment/courier integrations. Never put private API keys in front-end code.

## Files
- `index.html` — app layout
- `styles.css` — responsive blue UI and dark theme
- `app.js` — app behavior and sample food data
- `manifest.json` — PWA install metadata
- `sw.js` — offline cache
- `icons/` — app icons
