# BuyAnything production backend plan

The Android app is currently a native UI prototype with local in-memory state. Do not treat its demo checkout, role selector, order tracker, or dashboard metrics as production services.

## Recommended production shape
- Authentication: Firebase Authentication or a trusted OAuth/OIDC provider.
- Database: Cloud Firestore (or PostgreSQL with a secure API).
- Server-side business logic: Cloud Functions / Cloud Run or a typed REST API.
- Payments: a payment provider supported in your region; create and verify payment intents only on the server.
- Push: Firebase Cloud Messaging.
- Maps and courier position: a maps SDK plus a server-controlled location update flow and user consent.
- Observability: crash reporting, audit logs, alerting, and backups.

## Suggested collections / tables
- users: id, displayName, phone, role, createdAt
- restaurants: id, ownerId, name, address, geo, status, openingHours, rating
- menuItems: id, restaurantId, name, description, pricePaise, imageUrl, categoryId, isAvailable, veg
- categories: id, name, icon, imageUrl
- carts: userId, updatedAt, item snapshots
- orders: id, customerId, restaurantId, courierId, items snapshots, subtotalPaise, deliveryFeePaise, discountPaise, totalPaise, paymentStatus, orderStatus, timestamps
- deliveryTasks: id, orderId, courierId, pickupGeo, dropoffGeo, status, assignedAt
- promotions: id, code, rules, startsAt, endsAt, usageLimit
- supportTickets: id, orderId, customerId, status, messages
- reviews: id, orderId, customerId, restaurantId, rating, comment

## Order lifecycle
`placed -> payment_pending/paid -> restaurant_accepted -> preparing -> ready_for_pickup -> picked_up -> delivered`
Alternative terminal states: `cancelled`, `rejected`, `refund_pending`, `refunded`.

## Security requirements before launch
1. Enforce roles on the backend; never trust a role chosen in the Android UI.
2. Customers can read/write only their own profile and carts; order reads must be scoped to the customer, assigned courier, restaurant owner, or authorized admin.
3. Price, fees, discounts, and totals must be calculated server-side from current menu data.
4. Verify payment provider webhooks and make order creation idempotent.
5. Keep private credentials out of the app. Use server-side secrets.
6. Validate restaurant status, stock, delivery zones, coupon eligibility, and cancellation/refund policies.
7. Obtain consent for precise location and minimize retention of courier location.
8. Add privacy policy, terms, support, deletion/export workflows, and appropriate legal review.

## Firestore rule sketch — NOT production-ready
Use as a design checklist only; this project does not include Firebase configuration or enabled rules.

- users: a signed-in user can read/update their own profile; only trusted server/admin can assign roles.
- restaurants: public read for active stores; owner edits only their own store; admin moderation server-side.
- menuItems: public read when parent restaurant is active; owner edits only their own items.
- orders: create through a trusted backend endpoint; reads scoped by customerId, restaurant owner, assigned courier, or admin role.
- deliveryTasks: courier can update only allowed status transitions on their assigned task; all transitions validated server-side.
