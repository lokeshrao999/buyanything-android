package com.buyanything.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Blue = Color(0xFF1769FF)
private val Navy = Color(0xFF14213D)
private val Muted = Color(0xFF77829A)
private val Canvas = Color(0xFFF5F7FC)
private val Line = Color(0xFFE7ECF5)
private val Green = Color(0xFF16835F)

data class Dish(
    val id: Int, val name: String, val description: String, val price: Int,
    val oldPrice: Int, val emoji: String, val category: String, val rating: String,
    val mins: Int, val veg: Boolean, val tint: Color
)

private val menu = listOf(
    Dish(1, "Hyderabadi Chicken Biryani", "Dum-cooked rice, spices & mint raita", 189, 229, "🍛", "Biryani", "4.9", 22, false, Color(0xFFFFE7CF)),
    Dish(2, "Paneer Tikka Bowl", "Smoky paneer, salad & herbed rice", 159, 189, "🥗", "Veg", "4.8", 18, true, Color(0xFFDDF5E8)),
    Dish(3, "Classic Smash Burger", "Cheese, house sauce & toasted bun", 149, 179, "🍔", "Burgers", "4.7", 16, false, Color(0xFFFFE7C0)),
    Dish(4, "Crispy Chicken Shawarma", "Garlic sauce and warm soft pita", 129, 159, "🌯", "Shawarma", "4.8", 17, false, Color(0xFFF4E4D6)),
    Dish(5, "Mango Magic Smoothie", "Mango, yogurt & a little sunshine", 89, 109, "🥭", "Drinks", "4.6", 8, true, Color(0xFFFFF0B8)),
    Dish(6, "Loaded Masala Fries", "Golden fries, chatpata seasoning", 79, 99, "🍟", "Snacks", "4.6", 12, true, Color(0xFFFFEDC9)),
    Dish(7, "Margherita Pizza", "Mozzarella, basil & tomato sauce", 179, 219, "🍕", "Pizza", "4.7", 20, true, Color(0xFFFFDDD6)),
    Dish(8, "Chocolate Lava Cake", "Warm chocolate with a gooey centre", 99, 129, "🍰", "Desserts", "4.9", 14, true, Color(0xFFF2DDED)),
    Dish(9, "Cold Coffee Cloud", "Chilled coffee, creamy foam & cocoa", 99, 119, "🥤", "Drinks", "4.6", 7, true, Color(0xFFDDEAFF)),
    Dish(10, "Crispy Veg Momos", "Steamed dumplings & fiery chutney", 109, 129, "🥟", "Snacks", "4.5", 15, true, Color(0xFFE9E4FF))
)

enum class Role(val title: String) {
    CUSTOMER("Customer"), RESTAURANT("Restaurant"), COURIER("Delivery"), ADMIN("Admin")
}
enum class Page { HOME, FAVORITES, ORDERS, PROFILE, CART, DASHBOARD }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BuyAnythingApp() }
    }
}

@Composable
fun BuyAnythingApp() {
    var role by remember { mutableStateOf(Role.CUSTOMER) }
    var page by remember { mutableStateOf(Page.HOME) }
    var category by remember { mutableStateOf("All") }
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("All") }
    var sortLow by remember { mutableStateOf(false) }
    var dark by remember { mutableStateOf(false) }
    var eco by remember { mutableStateOf(false) }
    var checkout by remember { mutableStateOf(false) }
    var address by remember { mutableStateOf("") }
    var customerName by remember { mutableStateOf("") }
    var orderPlaced by remember { mutableStateOf(false) }
    var orderStatus by remember { mutableIntStateOf(0) }
    var favorites by remember { mutableStateOf(setOf<Int>()) }
    var cart by remember { mutableStateOf(mapOf<Int, Int>()) }
    var orderCount by remember { mutableIntStateOf(0) }
    val subtotal = cart.entries.sumOf { (id, qty) -> (menu.find { it.id == id }?.price ?: 0) * qty }
    val discount = if (subtotal >= 299) 80 else 0
    val deliveryFee = if (cart.isEmpty()) 0 else if (eco) 15 else 25
    val total = (subtotal + deliveryFee - discount).coerceAtLeast(0)

    val scheme = if (dark) darkColorScheme(
        primary = Color(0xFF76A5FF), background = Color(0xFF10182A),
        surface = Color(0xFF172239), onSurface = Color(0xFFEAF0FF),
        onBackground = Color(0xFFEAF0FF), secondary = Color(0xFF70D7B1)
    ) else lightColorScheme(
        primary = Blue, background = Canvas, surface = Color.White,
        onSurface = Navy, onBackground = Navy, secondary = Green
    )

    MaterialTheme(colorScheme = scheme) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxSize()) {
                AppHeader(role, onRole = { role = it; page = if (it == Role.CUSTOMER) Page.HOME else Page.DASHBOARD }, dark, { dark = !dark })
                when (role) {
                    Role.CUSTOMER -> when (page) {
                        Page.HOME -> CustomerHome(
                            query, { query = it }, category, { category = it }, filter, { filter = it },
                            sortLow, { sortLow = !sortLow }, favorites, cart,
                            onFavorite = { id -> favorites = if (id in favorites) favorites - id else favorites + id },
                            onAdd = { id -> cart = cart + (id to ((cart[id] ?: 0) + 1)) },
                            onCart = { page = Page.CART }
                        )
                        Page.FAVORITES -> DishListPage("Your favorites", menu.filter { it.id in favorites }, cart,
                            { id -> cart = cart + (id to ((cart[id] ?: 0) + 1)) }, { page = Page.HOME })
                        Page.ORDERS -> OrdersPage(orderCount, orderPlaced, orderStatus, { orderStatus = (orderStatus + 1).coerceAtMost(3) })
                        Page.PROFILE -> ProfilePage(favorites.size, orderCount, dark, { dark = !dark }, { eco = !eco }, eco)
                        Page.CART -> CartPage(cart, eco, { eco = it }, subtotal, discount, deliveryFee, total,
                            onQty = { id, delta ->
                                val next = ((cart[id] ?: 0) + delta)
                                cart = if (next <= 0) cart - id else cart + (id to next)
                            },
                            onCheckout = { checkout = true },
                            onBack = { page = Page.HOME })
                        else -> CustomerHome(query, { query = it }, category, { category = it }, filter, { filter = it },
                            sortLow, { sortLow = !sortLow }, favorites, cart,
                            onFavorite = { id -> favorites = if (id in favorites) favorites - id else favorites + id },
                            onAdd = { id -> cart = cart + (id to ((cart[id] ?: 0) + 1)) }, onCart = { page = Page.CART })
                    }
                    Role.RESTAURANT -> RestaurantDashboard()
                    Role.COURIER -> CourierDashboard()
                    Role.ADMIN -> AdminDashboard(orderCount)
                }
                if (role == Role.CUSTOMER) {
                    CustomerBottomNav(page, cart.values.sum(), { page = it })
                }
            }
            if (checkout) {
                AlertDialog(
                    onDismissRequest = { checkout = false },
                    title = { Text("Delivery details", fontWeight = FontWeight.Bold) },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("Demo checkout • no payment will be collected", color = Muted, fontSize = 12.sp)
                            OutlinedTextField(customerName, { customerName = it }, label = { Text("Your name") }, singleLine = true)
                            OutlinedTextField(address, { address = it }, label = { Text("Delivery address") }, minLines = 2)
                            Text("Order total: ₹$total", fontWeight = FontWeight.Bold)
                        }
                    },
                    confirmButton = {
                        Button(onClick = {
                            if (customerName.isNotBlank() && address.isNotBlank() && cart.isNotEmpty()) {
                                orderPlaced = true; orderStatus = 0; orderCount++; cart = emptyMap()
                                checkout = false; page = Page.ORDERS
                            }
                        }) { Text("Place demo order") }
                    },
                    dismissButton = { TextButton(onClick = { checkout = false }) { Text("Cancel") } }
                )
            }
        }
    }
}

@Composable
private fun AppHeader(role: Role, onRole: (Role) -> Unit, dark: Boolean, onTheme: () -> Unit) {
    Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(horizontal = 18.dp, vertical = 13.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(43.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(Blue, Color(0xFF79ABFF)))), contentAlignment = Alignment.Center) {
                Text("B", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text("buyanything.", fontWeight = FontWeight.Black, fontSize = 20.sp, color = MaterialTheme.colorScheme.onSurface, letterSpacing = (-.7).sp)
                Text(if (role == Role.CUSTOMER) "⌖  Delivering to  Home  ▾" else "${role.title} workspace", color = Muted, fontSize = 11.sp)
            }
            IconButton(onClick = onTheme) {
                Icon(if (dark) Icons.Default.LightMode else Icons.Default.DarkMode, contentDescription = "Toggle theme", tint = MaterialTheme.colorScheme.primary)
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            Role.values().forEach { r ->
                FilterChip(selected = role == r, onClick = { onRole(r) }, label = { Text(r.title, fontSize = 11.sp) })
            }
        }
    }
}

@Composable
private fun CustomerHome(
    query: String, onQuery: (String) -> Unit, category: String, onCategory: (String) -> Unit,
    filter: String, onFilter: (String) -> Unit, sortLow: Boolean, onSort: () -> Unit,
    favorites: Set<Int>, cart: Map<Int, Int>, onFavorite: (Int) -> Unit, onAdd: (Int) -> Unit, onCart: () -> Unit
) {
    val categories = listOf("All", "Biryani", "Burgers", "Shawarma", "Veg", "Drinks", "Snacks", "Pizza", "Desserts")
    val visible = menu.filter { dish ->
        (category == "All" || dish.category == category) &&
        (dish.name + dish.description + dish.category).contains(query, ignoreCase = true) &&
        when (filter) { "Veg" -> dish.veg; "Fast" -> dish.mins <= 20; "Popular" -> dish.rating.toDouble() >= 4.7; else -> true }
    }.let { if (sortLow) it.sortedBy { d -> d.price } else it }
    LazyColumn(Modifier.fillMaxHeight(0.86f), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(Brush.linearGradient(listOf(Color(0xFF0E4EDB), Color(0xFF4C91FF)))).padding(22.dp)) {
                Column(Modifier.fillMaxWidth(.67f)) {
                    Text("GOOD FOOD. GOOD MOOD.", color = Color(0xFFDCE8FF), fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.4.sp)
                    Spacer(Modifier.height(9.dp))
                    Text("Your cravings,\non the way.", color = Color.White, fontSize = 29.sp, lineHeight = 31.sp, fontWeight = FontWeight.Black, letterSpacing = (-1.2).sp)
                    Spacer(Modifier.height(8.dp))
                    Text("Fresh picks from places you'll love.", color = Color(0xFFEAF1FF), fontSize = 11.sp)
                    Spacer(Modifier.height(14.dp))
                    Surface(shape = RoundedCornerShape(11.dp), color = Color.White) {
                        Text("Explore today's deal  ↗", Modifier.clickable { onCategory("All") }.padding(horizontal = 13.dp, vertical = 10.dp), color = Blue, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                    }
                }
                Column(Modifier.align(Alignment.CenterEnd), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.size(112.dp).clip(CircleShape).background(Color(0xFFEAF1FF)), contentAlignment = Alignment.Center) {
                        Text("🍔", fontSize = 65.sp)
                    }
                    Surface(color = Color.White, shape = RoundedCornerShape(10.dp), shadowElevation = 4.dp) {
                        Column(Modifier.padding(horizontal = 12.dp, vertical = 7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("50% OFF", color = Blue, fontWeight = FontWeight.Black, fontSize = 12.sp)
                            Text("first order", color = Muted, fontSize = 8.sp)
                        }
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(MaterialTheme.colorScheme.surface).padding(horizontal = 13.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Search, null, tint = Blue)
                Spacer(Modifier.width(8.dp))
                BasicTextField(value = query, onValueChange = onQuery, modifier = Modifier.weight(1f).padding(vertical = 15.dp), singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(color = MaterialTheme.colorScheme.onSurface, fontSize = 12.sp), decorationBox = { inner ->
                    if (query.isEmpty()) Text("Search biryani, shawarma, juices…", color = Muted, fontSize = 12.sp)
                    inner()
                })
                if (query.isNotEmpty()) IconButton(onClick = { onQuery("") }, modifier = Modifier.size(28.dp)) { Icon(Icons.Default.Close, null, tint = Muted) }
            }
        }
        item {
            SectionHeader("Explore categories", "WHAT ARE YOU IN THE MOOD FOR?")
            Spacer(Modifier.height(10.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                categories.forEach { c ->
                    val emoji = when(c) { "All" -> "✨"; "Biryani" -> "🍛"; "Burgers" -> "🍔"; "Shawarma" -> "🌯"; "Veg" -> "🥗"; "Drinks" -> "🥤"; "Snacks" -> "🍟"; "Pizza" -> "🍕"; else -> "🍰" }
                    Column(Modifier.width(76.dp).clip(RoundedCornerShape(16.dp)).background(if (category == c) Color(0xFFEAF1FF) else MaterialTheme.colorScheme.surface).clickable { onCategory(c) }.padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(emoji, fontSize = 25.sp)
                        Spacer(Modifier.height(4.dp))
                        Text(c, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = if (category == c) Blue else MaterialTheme.colorScheme.onSurface, maxLines = 1)
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0xFFEAF1FF)).padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("⚡", fontSize = 22.sp)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("Blue Friday Specials", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Navy)
                    Text("Save ₹80 on orders above ₹299", fontSize = 10.sp, color = Muted)
                }
                Text("BLUE80", Modifier.clip(RoundedCornerShape(8.dp)).background(Color.White).padding(8.dp), color = Blue, fontSize = 10.sp, fontWeight = FontWeight.Black)
            }
        }
        item {
            Row(verticalAlignment = Alignment.Bottom) {
                Column(Modifier.weight(1f)) { Text("HANDPICKED FOR YOU", color = Blue, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.1.sp); Text(if (category == "All") "Popular near you" else "$category favorites", fontSize = 21.sp, fontWeight = FontWeight.Black, letterSpacing = (-.6).sp) }
                TextButton(onClick = onSort) { Text(if (sortLow) "Price ↑" else "Top picks ⇅", fontSize = 10.sp) }
            }
            Spacer(Modifier.height(9.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                listOf("All" to "All food", "Veg" to "🌱 Veg", "Fast" to "⚡ Under 20 min", "Popular" to "★ Popular").forEach { (key, label) ->
                    FilterChip(selected = filter == key, onClick = { onFilter(key) }, label = { Text(label, fontSize = 10.sp) })
                }
            }
        }
        if (visible.isEmpty()) item { Text("No dishes found. Try another search.", color = Muted, modifier = Modifier.padding(20.dp)) }
        items(visible.chunked(2)) { pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                pair.forEach { dish ->
                    DishCard(dish, dish.id in favorites, cart[dish.id] ?: 0, { onFavorite(dish.id) }, { onAdd(dish.id) }, Modifier.weight(1f))
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        item {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.surface).padding(16.dp)) {
                SectionHeader("The buyanything promise", "LITTLE THINGS, DONE BETTER.")
                Spacer(Modifier.height(12.dp))
                PromiseLine("🛵", "Order milestones", "A clear order timeline from confirmation to delivery.")
                PromiseLine("💙", "Favorites that stay", "Keep your go-to dishes close at hand.")
                PromiseLine("♻️", "Mindful packaging", "Choose a lower-waste delivery option.")
            }
        }
    }
}

@Composable
private fun DishCard(d: Dish, favorite: Boolean, quantity: Int, onFavorite: () -> Unit, onAdd: () -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(19.dp)).background(MaterialTheme.colorScheme.surface)) {
        Box(Modifier.fillMaxWidth().height(116.dp).background(d.tint), contentAlignment = Alignment.Center) {
            Text(d.emoji, fontSize = 58.sp)
            Surface(Modifier.align(Alignment.TopStart).padding(8.dp), color = Color.White, shape = RoundedCornerShape(6.dp)) {
                Text(if (d.rating.toDouble() >= 4.8) "BESTSELLER" else if (d.veg) "VEG PICK" else "POPULAR", Modifier.padding(horizontal = 6.dp, vertical = 4.dp), color = Blue, fontSize = 7.sp, fontWeight = FontWeight.Black)
            }
            IconButton(onClick = onFavorite, modifier = Modifier.align(Alignment.TopEnd).padding(5.dp).size(29.dp).clip(CircleShape).background(Color.White)) {
                Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (favorite) Color(0xFFE44D73) else Muted, modifier = Modifier.size(16.dp))
            }
        }
        Column(Modifier.padding(10.dp)) {
            Text(d.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 2, minLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 15.sp)
            Spacer(Modifier.height(4.dp))
            Text(d.description, fontSize = 9.sp, color = Muted, maxLines = 2, minLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 12.sp)
            Spacer(Modifier.height(7.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("★ ${d.rating}", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFFB77A00))
                Text("  ·  ◷ ${d.mins} min", fontSize = 9.sp, color = Muted)
            }
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("₹${d.price}", fontWeight = FontWeight.Black, fontSize = 15.sp)
                    Text("₹${d.oldPrice}", fontSize = 9.sp, color = Muted)
                }
                FilledTonalButton(onClick = onAdd, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp), modifier = Modifier.height(34.dp), shape = RoundedCornerShape(10.dp)) {
                    Text(if (quantity > 0) "+$quantity" else "+ Add", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun SectionHeader(title: String, kicker: String) {
    Column {
        Text(kicker, color = Blue, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.1.sp)
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.Black, letterSpacing = (-.5).sp)
    }
}

@Composable
private fun PromiseLine(emoji: String, title: String, desc: String) {
    Row(Modifier.padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFEAF1FF)), contentAlignment = Alignment.Center) { Text(emoji, fontSize = 19.sp) }
        Spacer(Modifier.width(10.dp))
        Column { Text(title, fontWeight = FontWeight.Bold, fontSize = 11.sp); Text(desc, color = Muted, fontSize = 10.sp) }
    }
}

@Composable
private fun CustomerBottomNav(page: Page, cartCount: Int, onPage: (Page) -> Unit) {
    NavigationBar(containerColor = MaterialTheme.colorScheme.surface, tonalElevation = 8.dp) {
        NavigationBarItem(selected = page == Page.HOME, onClick = { onPage(Page.HOME) }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home", fontSize = 9.sp) })
        NavigationBarItem(selected = page == Page.FAVORITES, onClick = { onPage(Page.FAVORITES) }, icon = { Icon(Icons.Default.FavoriteBorder, null) }, label = { Text("Saved", fontSize = 9.sp) })
        NavigationBarItem(selected = page == Page.CART, onClick = { onPage(Page.CART) }, icon = { BadgedBox(badge = { if (cartCount > 0) Badge { Text(cartCount.toString()) } }) { Icon(Icons.Default.ShoppingBag, null) } }, label = { Text("Cart", fontSize = 9.sp) })
        NavigationBarItem(selected = page == Page.ORDERS, onClick = { onPage(Page.ORDERS) }, icon = { Icon(Icons.Default.ReceiptLong, null) }, label = { Text("Orders", fontSize = 9.sp) })
        NavigationBarItem(selected = page == Page.PROFILE, onClick = { onPage(Page.PROFILE) }, icon = { Icon(Icons.Default.Person, null) }, label = { Text("Profile", fontSize = 9.sp) })
    }
}

@Composable
private fun CartPage(cart: Map<Int, Int>, eco: Boolean, onEco: (Boolean) -> Unit, subtotal: Int, discount: Int, delivery: Int, total: Int, onQty: (Int, Int) -> Unit, onCheckout: () -> Unit, onBack: () -> Unit) {
    LazyColumn(Modifier.fillMaxHeight(0.86f), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { TextButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null); Text(" Back to menu") }; Text("Your cart", fontSize = 28.sp, fontWeight = FontWeight.Black); Text("YOUR PICKS, ALL IN ONE PLACE", color = Blue, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold) }
        if (cart.isEmpty()) item { EmptyCard("🛍", "Your cart is taking a nap", "Add a dish from the home screen to get started.") }
        items(cart.entries.toList()) { (id, qty) ->
            val d = menu.first { it.id == id }
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(56.dp).clip(RoundedCornerShape(12.dp)).background(d.tint), contentAlignment = Alignment.Center) { Text(d.emoji, fontSize = 30.sp) }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) { Text(d.name, fontWeight = FontWeight.Bold, fontSize = 12.sp); Text("₹${d.price} each", color = Muted, fontSize = 10.sp) }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { onQty(id, -1) }) { Icon(Icons.Default.RemoveCircleOutline, null, tint = Blue) }
                    Text(qty.toString(), fontWeight = FontWeight.Bold)
                    IconButton(onClick = { onQty(id, 1) }) { Icon(Icons.Default.AddCircleOutline, null, tint = Blue) }
                }
            }
        }
        if (cart.isNotEmpty()) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("🌿 Minimal packaging", fontWeight = FontWeight.Bold, fontSize = 13.sp); Text("Choose a lower-waste option", color = Muted, fontSize = 10.sp) }
                    Switch(checked = eco, onCheckedChange = onEco)
                }
            }
            item {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.surface).padding(17.dp)) {
                    Text("Bill details", fontWeight = FontWeight.Black, fontSize = 17.sp)
                    BillRow("Item total", "₹$subtotal")
                    BillRow("Delivery fee", "₹$delivery")
                    BillRow("Blue Friday savings", "−₹$discount", Green)
                    HorizontalDivider(color = Line, modifier = Modifier.padding(vertical = 7.dp))
                    BillRow("Total", "₹$total", MaterialTheme.colorScheme.onSurface, true)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = onCheckout, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(14.dp), enabled = cart.isNotEmpty()) { Text("Continue to checkout   →", fontWeight = FontWeight.Bold) }
                    Text("Demo checkout • no payment collected", modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 8.dp), color = Muted, fontSize = 9.sp)
                }
            }
        }
    }
}

@Composable
private fun BillRow(label: String, value: String, color: Color = MaterialTheme.colorScheme.onSurface, bold: Boolean = false) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = if (bold) MaterialTheme.colorScheme.onSurface else Muted, fontSize = if (bold) 14.sp else 11.sp, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal)
        Text(value, color = color, fontSize = if (bold) 15.sp else 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun DishListPage(title: String, dishes: List<Dish>, cart: Map<Int, Int>, onAdd: (Int) -> Unit, onBack: () -> Unit) {
    LazyColumn(Modifier.fillMaxHeight(0.86f), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { TextButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null); Text(" Back") }; Text(title, fontSize = 27.sp, fontWeight = FontWeight.Black) }
        if (dishes.isEmpty()) item { EmptyCard("💙", "No favorites saved yet", "Tap the heart on any dish to save it here.") }
        items(dishes) { d ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(58.dp).clip(RoundedCornerShape(13.dp)).background(d.tint), contentAlignment = Alignment.Center) { Text(d.emoji, fontSize = 30.sp) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) { Text(d.name, fontWeight = FontWeight.Bold, fontSize = 12.sp); Text("★ ${d.rating} · ₹${d.price}", color = Muted, fontSize = 10.sp) }
                FilledTonalButton(onClick = { onAdd(d.id) }) { Text(if ((cart[d.id] ?: 0) > 0) "+${cart[d.id]}" else "+ Add") }
            }
        }
    }
}

@Composable
private fun OrdersPage(orderCount: Int, orderPlaced: Boolean, status: Int, onNext: () -> Unit) {
    val stages = listOf("Order confirmed", "Being prepared", "Out for delivery", "Delivered")
    val descriptions = listOf("Your order has reached the kitchen.", "The restaurant is preparing your food.", "Your delivery partner is on the way.", "Enjoy your meal!")
    LazyColumn(Modifier.fillMaxHeight(0.86f), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Your orders", fontSize = 28.sp, fontWeight = FontWeight.Black); Text("ORDER HISTORY & DELIVERY STATUS", color = Blue, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold) }
        item {
            if (!orderPlaced) EmptyCard("🧾", "No orders yet", "When you place a demo order, its progress will appear here.")
            else {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.surface).padding(17.dp)) {
                    Text("ORDER BA${10000 + orderCount}", color = Blue, fontWeight = FontWeight.ExtraBold, fontSize = 10.sp)
                    Text("Your food journey", fontWeight = FontWeight.Black, fontSize = 21.sp)
                    Text("Illustrative tracking timeline — not connected to a live courier.", color = Muted, fontSize = 10.sp)
                    Spacer(Modifier.height(12.dp))
                    stages.forEachIndexed { index, stage ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(36.dp).clip(CircleShape).background(if (index <= status) Color(0xFFDDF5E8) else Canvas), contentAlignment = Alignment.Center) {
                                Icon(if (index <= status) Icons.Default.Check else Icons.Default.Circle, null, tint = if (index <= status) Green else Muted, modifier = Modifier.size(17.dp))
                            }
                            Spacer(Modifier.width(10.dp))
                            Column { Text(stage, fontWeight = FontWeight.Bold, fontSize = 12.sp); Text(descriptions[index], color = Muted, fontSize = 10.sp) }
                        }
                    }
                    Button(onClick = onNext, modifier = Modifier.fillMaxWidth(), enabled = status < 3) { Text(if (status < 3) "Simulate next step →" else "Delivered ✓") }
                }
            }
        }
        item { Text("Order history: $orderCount demo order(s)", color = Muted, fontSize = 11.sp) }
    }
}

@Composable
private fun ProfilePage(favorites: Int, orders: Int, dark: Boolean, onTheme: () -> Unit, onEco: () -> Unit, eco: Boolean) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Your profile", fontSize = 28.sp, fontWeight = FontWeight.Black)
        Text("YOUR BUYANYTHING", color = Blue, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("$orders", "Demo orders", Modifier.weight(1f))
            StatCard("$favorites", "Saved dishes", Modifier.weight(1f))
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(16.dp)) {
                Text("App preferences", fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.DarkMode, null, tint = Blue); Spacer(Modifier.width(10.dp)); Text("Dark mode", Modifier.weight(1f)); Switch(dark, { onTheme() }) }
                Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Eco, null, tint = Green); Spacer(Modifier.width(10.dp)); Text("Minimal packaging default", Modifier.weight(1f)); Switch(eco, { onEco() }) }
            }
        }
        EmptyCard("🔐", "Your data stays on this demo screen", "Sign-in and cloud sync are not connected yet. Add a secure backend before launching.")
    }
}

@Composable
private fun RestaurantDashboard() {
    LazyColumn(Modifier.fillMaxHeight(0.86f), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("Restaurant studio", fontSize = 27.sp, fontWeight = FontWeight.Black); Text("OWNER DASHBOARD · DEMO DATA", color = Blue, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { StatCard("₹12,480", "Today's sales", Modifier.weight(1f)); StatCard("38", "Orders today", Modifier.weight(1f)) } }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { StatCard("4.8 ★", "Store rating", Modifier.weight(1f)); StatCard("21 min", "Prep average", Modifier.weight(1f)) } }
        item { SectionHeader("Incoming orders", "ACTION REQUIRED") }
        items(listOf("BA-4812 · Chicken Biryani · 2 items" to "Accept order", "BA-4811 · Paneer Bowl · 1 item" to "Mark preparing", "BA-4809 · Burger combo · 3 items" to "Ready for pickup")) { (order, action) ->
            var accepted by remember { mutableStateOf(false) }
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface).padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFEAF1FF)), contentAlignment = Alignment.Center) { Text("🍽", fontSize = 21.sp) }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) { Text(order, fontWeight = FontWeight.Bold, fontSize = 11.sp); Text(if (accepted) "Updated in demo" else "Awaiting action", color = Muted, fontSize = 10.sp) }
                TextButton(onClick = { accepted = true }) { Text(if (accepted) "Done ✓" else action, fontSize = 9.sp) }
            }
        }
        item { SectionHeader("Menu management", "QUICK ACTIONS") }
        item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { ActionTile("＋", "Add dish", Modifier.weight(1f)); ActionTile("◉", "Stock status", Modifier.weight(1f)); ActionTile("⌁", "Offers", Modifier.weight(1f)) } }
        item { Text("Restaurant metrics and order rows are sample data. Actions are local UI demos only.", color = Muted, fontSize = 10.sp) }
    }
}

@Composable
private fun CourierDashboard() {
    var available by remember { mutableStateOf(true) }
    var picked by remember { mutableStateOf(false) }
    LazyColumn(Modifier.fillMaxHeight(0.86f), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("Delivery partner", fontSize = 27.sp, fontWeight = FontWeight.Black); Text("YOUR SHIFT, AT A GLANCE", color = Blue, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { StatCard("₹840", "Today's earnings", Modifier.weight(1f)); StatCard("7", "Trips completed", Modifier.weight(1f)) } }
        item {
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(MaterialTheme.colorScheme.surface).padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text("Availability", fontWeight = FontWeight.Bold); Text(if (available) "You're shown as online in this demo" else "You're offline in this demo", color = Muted, fontSize = 10.sp) }
                Switch(available, { available = it })
            }
        }
        item { SectionHeader("Suggested delivery", "NEARBY PICKUP · DEMO") }
        item {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.surface).padding(17.dp)) {
                Text("🛵  BA-4812", color = Blue, fontWeight = FontWeight.ExtraBold, fontSize = 11.sp)
                Text("Spice Route Kitchen", fontSize = 19.sp, fontWeight = FontWeight.Black)
                Text("2.1 km to pickup · 3.4 km to customer", color = Muted, fontSize = 11.sp)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Text("₹68 payout", color = Green, fontWeight = FontWeight.Bold, fontSize = 12.sp); Spacer(Modifier.weight(1f)); Text("Est. 18 min", color = Muted, fontSize = 11.sp) }
                Button(onClick = { picked = !picked }, enabled = available, modifier = Modifier.fillMaxWidth()) { Text(if (picked) "Pickup accepted ✓" else "Accept delivery") }
            }
        }
        item { Text("No GPS, navigation, customer contact, or real dispatch is connected in this demo.", color = Muted, fontSize = 10.sp) }
    }
}

@Composable
private fun AdminDashboard(orderCount: Int) {
    LazyColumn(Modifier.fillMaxHeight(0.86f), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("Platform control", fontSize = 27.sp, fontWeight = FontWeight.Black); Text("ADMIN OVERVIEW · DEMO METRICS", color = Blue, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { StatCard("1,284", "Platform orders", Modifier.weight(1f)); StatCard("₹86.4k", "Gross sales", Modifier.weight(1f)) } }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { StatCard("42", "Restaurants", Modifier.weight(1f)); StatCard("86", "Delivery partners", Modifier.weight(1f)) } }
        item { SectionHeader("Platform operations", "QUICK HEALTH CHECK") }
        items(listOf("Restaurant approvals" to "3 pending", "Customer support" to "8 open tickets", "Delivery coverage" to "12 zones active", "Offers & campaigns" to "2 campaigns live", "Safety & refunds" to "Review queue")) { (label, value) ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(MaterialTheme.colorScheme.surface).padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(36.dp).clip(RoundedCornerShape(11.dp)).background(Color(0xFFEAF1FF)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Dashboard, null, tint = Blue) }
                Spacer(Modifier.width(10.dp))
                Text(label, Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text(value, color = Muted, fontSize = 10.sp)
            }
        }
        item { Text("All admin metrics are illustrative. A production system must enforce role permissions on the server.", color = Muted, fontSize = 10.sp) }
    }
}

@Composable
private fun StatCard(value: String, label: String, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(17.dp)).background(MaterialTheme.colorScheme.surface).padding(15.dp)) {
        Text(value, color = Blue, fontSize = 22.sp, fontWeight = FontWeight.Black, letterSpacing = (-.5).sp)
        Text(label, color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun ActionTile(icon: String, label: String, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surface).clickable { }.padding(vertical = 15.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(icon, color = Blue, fontSize = 22.sp)
        Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun EmptyCard(emoji: String, title: String, desc: String) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surface).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(emoji, fontSize = 36.sp)
        Spacer(Modifier.height(8.dp))
        Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Spacer(Modifier.height(4.dp))
        Text(desc, color = Muted, fontSize = 11.sp)
    }
}
