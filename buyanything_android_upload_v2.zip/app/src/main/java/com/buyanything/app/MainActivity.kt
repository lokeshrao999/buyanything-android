package com.buyanything.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Blue=Color(0xFF3267E3); private val Pale=Color(0xFFF4F6FA); private val Ink=Color(0xFF172033); private val Muted=Color(0xFF778197)
data class Food(val name:String,val shop:String,val price:Int,val rating:String,val emoji:String,val tag:String)
private val menu=listOf(Food("Hyderabadi Chicken Biryani","Spice Garden",189,"4.8","🍛","Bestseller"),Food("Paneer Butter Masala","Curry House",159,"4.7","🍲","Veg"),Food("Classic Cheese Burger","Burger District",129,"4.6","🍔","Popular"),Food("Masala Dosa","South Street",89,"4.7","🥞","South Indian"),Food("Margherita Pizza","Oven Story",219,"4.5","🍕","Fresh"),Food("Chocolate Brownie","Sweet Spot",99,"4.9","🍫","Dessert"))
class MainActivity:ComponentActivity(){override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{App()}}}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun App(){
 var query by remember{mutableStateOf("")}; var category by remember{mutableStateOf("All")}; var cart by remember{mutableStateOf(mapOf<String,Int>())}; var tab by remember{mutableIntStateOf(0)}; var checkout by remember{mutableStateOf(false)}; var orders by remember{mutableStateOf(false)}
 val count=cart.values.sum(); val total=menu.sumOf{it.price*(cart[it.name]?:0)}
 MaterialTheme(colorScheme=lightColorScheme(primary=Blue,background=Pale,surface=Color.White,onSurface=Ink)){
 Scaffold(containerColor=Pale,topBar={CenterAlignedTopAppBar(title={Row(verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(34.dp).background(Blue,RoundedCornerShape(10.dp)),contentAlignment=Alignment.Center){Icon(Icons.Default.DeliveryDining,null,tint=Color.White)};Spacer(Modifier.width(8.dp));Text("BuyAnything",fontWeight=FontWeight.ExtraBold,color=Ink)}},actions={IconButton(onClick={orders=true}){Icon(Icons.Default.ReceiptLong,"Orders")}},colors=TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor=Pale))},
 bottomBar={NavigationBar(containerColor=Color.White){NavigationBarItem(tab==0,{tab=0},{Icon(Icons.Default.Home,null)},label={Text("Home")});NavigationBarItem(tab==1,{tab=1},{Icon(Icons.Default.FavoriteBorder,null)},label={Text("Saved")});NavigationBarItem(tab==2,{tab=2},{Icon(Icons.Default.ShoppingCart,null)},label={Text("Cart${if(count>0)" ($count)" else ""}")});NavigationBarItem(tab==3,{tab=3},{Icon(Icons.Default.PersonOutline,null)},label={Text("Profile")})}},
 floatingActionButton={if(tab==0&&count>0)ExtendedFloatingActionButton(onClick={checkout=true},containerColor=Blue,contentColor=Color.White,icon={Icon(Icons.Default.ShoppingBag,null)},text={Text("Cart · ₹$total")})}
 ){pad->when(tab){
 0->Home(Modifier.padding(pad),query,{query=it},category,{category=it}){f->cart=cart+(f.name to ((cart[f.name]?:0)+1))}
 1->Column(Modifier.fillMaxSize().padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Icon(Icons.Default.FavoriteBorder,null,tint=Blue,modifier=Modifier.size(44.dp));Text("Your saved items",fontSize=22.sp,fontWeight=FontWeight.Bold);Text("Favourite meals will appear here.",color=Muted)}
 2->Cart(cart,{n->cart=cart+(n to ((cart[n]?:0)+1))},{n->val c=(cart[n]?:0)-1;cart=if(c<=0)cart-n else cart+(n to c)} ){checkout=true}
 else->Column(Modifier.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Text("Your profile",fontSize=26.sp,fontWeight=FontWeight.ExtraBold);Card{Row(Modifier.padding(18.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Person,null,tint=Blue,modifier=Modifier.size(40.dp));Spacer(Modifier.width(12.dp));Column{Text("Welcome to BuyAnything",fontWeight=FontWeight.Bold);Text("Sign-in service not connected",color=Muted,fontSize=12.sp)}}};OutlinedButton(onClick={orders=true},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.ReceiptLong,null);Spacer(Modifier.width(8.dp));Text("My orders")}}
 }}
 if(checkout)AlertDialog(onDismissRequest={checkout=false},title={Text("Demo checkout")},text={Text(if(count==0)"Your cart is empty." else "Items: $count\nTotal: ₹$total\nDemo only — no payment will be taken.")},confirmButton={TextButton(onClick={if(count>0)cart=emptyMap();checkout=false}){Text(if(count>0)"Place demo order" else "OK")}},dismissButton={TextButton(onClick={checkout=false}){Text("Cancel")}})
 if(orders)AlertDialog(onDismissRequest={orders=false},title={Text("Your orders")},text={Text("Demo order history. Live tracking is not connected yet.")},confirmButton={TextButton(onClick={orders=false}){Text("Close")}})
 }
}

@Composable private fun Home(modifier:Modifier,query:String,onQuery:(String)->Unit,category:String,onCategory:(String)->Unit,onAdd:(Food)->Unit){
 val foods=menu.filter{(it.name.contains(query,true)||it.shop.contains(query,true))&&(category=="All"||(category=="Veg"&&(it.tag=="Veg"||it.name.contains("Dosa")))||(category=="Popular"&&(it.tag=="Popular"||it.tag=="Bestseller")))}
 LazyColumn(modifier.fillMaxSize(),contentPadding=PaddingValues(18.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
 item{Column{Text("Good food, delivered.",fontSize=27.sp,fontWeight=FontWeight.ExtraBold,color=Ink);Text("Fresh picks for your next meal",color=Muted);Spacer(Modifier.height(12.dp));Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.LocationOn,null,tint=Blue);Text("Delivering to · Choose your location",fontSize=12.sp)}}}
 item{OutlinedTextField(query,onQuery,modifier=Modifier.fillMaxWidth(),placeholder={Text("Search dishes or restaurants")},leadingIcon={Icon(Icons.Default.Search,null)},singleLine=true,shape=RoundedCornerShape(16.dp))}
 item{Card(shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFF101828))){Row(Modifier.fillMaxWidth().padding(18.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("MEAL DEAL",color=Color(0xFFB9CCFF),fontSize=11.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(7.dp));Text("A little treat.\nA lot of flavour.",color=Color.White,fontSize=22.sp,fontWeight=FontWeight.Bold);Text("Explore today's favourites",color=Color.LightGray,fontSize=12.sp)};Text("🍱",fontSize=46.sp)}}}
 item{Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf("All","Veg","Popular").forEach{FilterChip(category==it,{onCategory(it)},label={Text(it)})}}}
 item{Text("Recommended for you",fontSize=19.sp,fontWeight=FontWeight.Bold,color=Ink)}
 items(foods){f->Card(shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=Color.White),elevation=CardDefaults.cardElevation(1.dp)){Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(72.dp).background(Color(0xFFF0F3FA),RoundedCornerShape(16.dp)),contentAlignment=Alignment.Center){Text(f.emoji,fontSize=36.sp)};Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(f.tag.uppercase(),color=Blue,fontSize=9.sp,fontWeight=FontWeight.Bold);Text(f.name,fontWeight=FontWeight.Bold,fontSize=14.sp);Text(f.shop,color=Muted,fontSize=12.sp);Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Star,null,tint=Color(0xFFFFB020),modifier=Modifier.size(14.dp));Text(" ${f.rating}   ₹${f.price}",fontWeight=FontWeight.SemiBold,fontSize=12.sp)}};FilledTonalButton(onClick={onAdd(f)},contentPadding=PaddingValues(horizontal=9.dp)){Icon(Icons.Default.Add,null,modifier=Modifier.size(16.dp));Text("Add")}}}}
 }
}
@Composable private fun Cart(cart:Map<String,Int>,plus:(String)->Unit,minus:(String)->Unit,checkout:()->Unit){
 val total=menu.sumOf{it.price*(cart[it.name]?:0)}
 Column(Modifier.fillMaxSize().padding(18.dp)){Text("Your cart",fontSize=26.sp,fontWeight=FontWeight.ExtraBold,color=Ink);Spacer(Modifier.height(14.dp))
 if(cart.isEmpty())Card{Column(Modifier.fillMaxWidth().padding(26.dp),horizontalAlignment=Alignment.CenterHorizontally){Icon(Icons.Default.ShoppingCart,null,tint=Blue,modifier=Modifier.size(42.dp));Text("Your cart is empty",fontWeight=FontWeight.Bold);Text("Add a meal from Home.",color=Muted)}}
 else{LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(10.dp)){items(cart.keys.toList()){name->val f=menu.first{it.name==name};Card{Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically){Text(f.emoji,fontSize=26.sp);Spacer(Modifier.width(8.dp));Column(Modifier.weight(1f)){Text(name,fontWeight=FontWeight.Bold);Text("₹${f.price} each",color=Muted,fontSize=12.sp)};IconButton(onClick={minus(name)}){Icon(Icons.Default.RemoveCircleOutline,null)};Text("${cart[name]}");IconButton(onClick={plus(name)}){Icon(Icons.Default.AddCircleOutline,null)}}}};Spacer(Modifier.height(12.dp));Text("Total: ₹$total",fontSize=21.sp,fontWeight=FontWeight.Bold);Button(onClick=checkout,modifier=Modifier.fillMaxWidth()){Text("Continue to checkout")}}
 }
}
